package ir.uciran.uctor

import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.io.File

/** Routes the whole device through the local Tor SOCKS listener. */
class FullVpnService : VpnService() {
    companion object {
        const val ACTION_START = "ir.uciran.uctor.vpn.START"
        const val ACTION_STOP = "ir.uciran.uctor.vpn.STOP"
        const val ACTION_PAUSE = "ir.uciran.uctor.vpn.PAUSE"
        const val ACTION_RESUME = "ir.uciran.uctor.vpn.RESUME"
        const val ACTION_STATUS = "ir.uciran.uctor.vpn.STATUS"
        const val EXTRA_READY = "ready"
        const val EXTRA_ERROR = "error"
        private const val ID = 1002
        fun start(ctx: android.content.Context) = ContextCompat.startForegroundService(ctx, Intent(ctx, FullVpnService::class.java).setAction(ACTION_START))
        fun stop(ctx: android.content.Context) = ctx.startService(Intent(ctx, FullVpnService::class.java).setAction(ACTION_STOP))
        fun togglePause(ctx: android.content.Context) = ctx.startService(Intent(ctx, FullVpnService::class.java).setAction(if (Prefs(ctx).vpnPaused) ACTION_RESUME else ACTION_PAUSE))
    }

    private var tun: ParcelFileDescriptor? = null
    private var running = false
    private var lastRx = android.net.TrafficStats.getTotalRxBytes()
    private var lastTx = android.net.TrafficStats.getTotalTxBytes()
    private val meter = android.os.Handler(android.os.Looper.getMainLooper())
    private val meterTick = object : Runnable { override fun run() { updateNotification(); meter.postDelayed(this, 1000) } }

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopTunnel(); return START_NOT_STICKY }
            ACTION_PAUSE -> { setPaused(true); return START_STICKY }
            ACTION_RESUME -> { setPaused(false); return START_STICKY }
        }
        foreground()
        meter.removeCallbacks(meterTick); meter.post(meterTick)
        if (!running) startTunnel()
        return START_STICKY
    }

    private fun startTunnel() {
        val p = Prefs(this)
        if (p.socksPort <= 0) {
            broadcast(false, "Tor SOCKS هنوز آماده نیست")
            return
        }
        try {
            val b = Builder()
                .setSession("UC Tor")
                .setMtu(1500)
                .addAddress("198.18.0.1", 15)
                .addRoute("0.0.0.0", 0)
                .addAddress("fd00:0c::1", 64)
                .addRoute("::", 0)
                .addDnsServer("198.18.0.2")
            if (p.tunnelMode == "selected") {
                // Allowed and disallowed lists are mutually exclusive on Android.
                p.selectedApps.forEach { runCatching { b.addAllowedApplication(it) } }
            } else {
                // Keep UC Tor itself out or its Tor/SOCKS traffic loops into the TUN.
                b.addDisallowedApplication(packageName)
            }
            tun = b.establish() ?: error("Android VPN interface could not be established")
            if (!waitForLocalPort(p.socksPort, 8_000)) error("Tor SOCKS آماده نیست")
            val fd = tun!!.detachFd()
            val cfg = File(filesDir, "hev-tun.conf")
            // hev-socks5-tunnel uses this exact lowercase YAML schema.
            // mapdns captures DNS requests from Android's synthetic DNS address and
            // resolves them through the SOCKS5/Tor path, avoiding plaintext DNS leaks.
            cfg.writeText("""
                tunnel:
                  name: tun0
                  mtu: 1500
                  ipv4: 198.18.0.1
                  ipv6: 'fc00::1'
                socks5:
                  address: 127.0.0.1
                  port: ${p.socksPort}
                  udp: 'udp'
                mapdns:
                  address: 198.18.0.2
                  port: 53
                  cache-size: 10000
                misc:
                  log-level: warn
            """.trimIndent())
            if (!Tun2SocksBridge.start(cfg, fd)) error("tun2socks native library is not available")
            if (!waitForTunnel(8_000L)) error("تونل TUN اجرا نشد")
            running = true
            Prefs(this).vpnRunning = true
            broadcast(true, "")
        } catch (t: Throwable) {
            tun?.close(); tun = null
            Prefs(this).vpnRunning = false
            val msg = t.message ?: t.javaClass.simpleName
            File(filesDir, "vpn.state").writeText("error:$msg")
            broadcast(false, msg)
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun waitForTunnel(timeoutMs: Long): Boolean {
        val until = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < until) {
            if (Tun2SocksBridge.isRunning()) return true
            Thread.sleep(150)
        }
        return false
    }

    private fun waitForLocalPort(port: Int, timeoutMs: Long): Boolean {
        val until = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < until) {
            try { java.net.Socket("127.0.0.1", port).use { return true } } catch (_: Exception) { Thread.sleep(150) }
        }
        return false
    }

    private fun stopTunnel() {
        runCatching { Tun2SocksBridge.stop() }
        tun?.close(); tun = null
        running = false
        Prefs(this).vpnRunning = false
        broadcast(false, "stopped")
        meter.removeCallbacks(meterTick)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun broadcast(ready: Boolean, error: String) {
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra(EXTRA_READY, ready).putExtra(EXTRA_ERROR, error))
    }

    private fun updateNotification() { if (running && !Prefs(this).vpnPaused) foreground() }

    private fun foreground() {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val n: Notification = NotificationCompat.Builder(this, UcTorApp.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_uc)
            .setContentTitle("UC Tor")
            .setContentText(if (Prefs(this).vpnPaused) "موقتاً متوقف است" else "${TrafficMeter.text(speedRx())} ↓   ${TrafficMeter.text(speedTx())} ↑")
            .setContentIntent(open)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, if (Prefs(this).vpnPaused) "اتصال مجدد" else "توقف موقت", action(if (Prefs(this).vpnPaused) ACTION_RESUME else ACTION_PAUSE, 1))
            .addAction(0, "قطع کامل", action(ACTION_STOP, 2))
            .build()
        val type = if (Build.VERSION.SDK_INT >= 29) android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, ID, n, type)
    }

    private var prevStats = longArrayOf(0L, 0L)
    private fun speedRx(): Long {
        val a = Tun2SocksBridge.stats(); val n = a.getOrNull(0) ?: 0L
        val d = (n - prevStats[0]).coerceAtLeast(0); prevStats[0] = n; return d
    }
    private fun speedTx(): Long {
        val a = Tun2SocksBridge.stats(); val n = a.getOrNull(1) ?: 0L
        val d = (n - prevStats[1]).coerceAtLeast(0); prevStats[1] = n; return d
    }
    private fun action(a: String, id: Int): PendingIntent = PendingIntent.getService(this, id, Intent(this, FullVpnService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    private fun setPaused(value: Boolean) {
        Prefs(this).vpnPaused = value
        if (value) {
            runCatching { Tun2SocksBridge.stop() }
            tun?.close(); tun = null
            running = false
            Prefs(this).vpnRunning = false
            broadcast(false, "paused")
        } else if (!running) startTunnel()
        foreground()
    }
}

/** Reflection keeps the Kotlin source buildable before the GitHub Action downloads the AAR. */
object Tun2SocksBridge {
    private var cls: Class<*>? = null
    private var service: Any? = null
    private fun load(): Class<*>? = runCatching { Class.forName("hev.htproxy.TProxyService") }.getOrNull()
    fun start(config: File, fd: Int): Boolean = runCatching {
        val c = load() ?: return false
        val m = c.getMethod("TProxyStartService", String::class.java, Integer.TYPE)
        val ok = m.invoke(null, config.absolutePath, fd) as? Boolean ?: false
        if (ok) { cls = c; service = c }
        ok
    }.getOrDefault(false)
    fun isRunning(): Boolean = runCatching { (cls?.getMethod("TProxyIsRunning")?.invoke(null) as? Boolean) == true }.getOrDefault(false)
    fun stats(): LongArray = runCatching { (cls?.getMethod("TProxyGetStats")?.invoke(null) as? LongArray) ?: longArrayOf(0L, 0L) }.getOrDefault(longArrayOf(0L, 0L))
    fun stop() { runCatching { cls?.getMethod("TProxyStopService")?.invoke(null) }; cls = null; service = null }
}
